<?php

function isCommandLineInterface()
{
    return (php_sapi_name() === 'cli');
}

if (!isCommandLineInterface()) {
  die('must by cli');
}
  session_start();
  date_default_timezone_set('Asia/Taipei');
  include 'inc/config.php';
  include 'inc/common.php';

$info = rsInfo('mail',"is_send=0 order by id asc");

//print_r($info);
if (!$info['id']) exit;

require 'inc/mail/PHPMailerAutoload.php';

mb_internal_encoding('UTF-8'); 

$mail = new PHPMailer;	
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->Debugoutput = 'html';
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "erdc@ms.nlps.tyc.edu.tw";
$mail->Password = "zj32l3wj06";

$mail->setFrom('erdc@ms.nlps.tyc.edu.tw', mb_encode_mimeheader('領航中心','UTF-8'));
$mail->addAddress($info['email'], mb_encode_mimeheader('管理員','UTF-8'));
$mail->Subject = mb_encode_mimeheader('儲訓網-新增徵才公告通知','UTF-8');
$content = $info['con'];

$mail->msgHTML($content);

$data=array('is_send'=>1,'send_time'=>date('Y-m-d H:i:s'));

if (!$mail->send()) {
   // $content .= "<div>信件發送失敗！</div>";
   // echo "Mailer Error: " . $mail->ErrorInfo;
   $data['ok_send']=0;
} else {
   //  $content .= "<div>信件已經發送成功。</div>";//寄信成功就會顯示的提示訊息
   $data['ok_send']=1;
}
rsEdit('mail',$data,"id={$info['id']}");

?>
