<?php
$tn='admin';
$caption = '管理登入';
if (aid()) {

} else {
	require 'admin/loginform.php';

}	
?>