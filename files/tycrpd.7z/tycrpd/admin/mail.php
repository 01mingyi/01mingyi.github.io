<?php
//$content.="更改Email：此功能為學校公布新的徵才公告時將通知設定的Email";

if (@$_POST['act']=='save') {



	$data=array('val'=>$_POST['email']);
    rsEdit('sys',$data,"tag='admin_email'");  

    //$content .="<p>密碼修改完成</p>";
    $content .= redirect("Email修改完成",'index.php?do=admin',1);	
	
  
} else {
	
$uname=aid();
if ($uname) {
//$var = rsInfo('admin',"uname='$uname'");
//echo $uname;
$email = get_sys('admin_email');
$content.= "<form id='editForm' method='POST' action='index.php?do={$do}' >
<table class='table table-bordered ' align='center'>
<tr><td>說明</td><td>此功能為學校公布新的徵才公告時將通知設定的Email</td></tr>
<tr><td>Email</td><td><input id='email' type=text name='email' value='$email'>
                     
</td></tr>
<tr><td>儲存</td><td><input type=submit value='確認儲存'><input type=hidden name=act value='save'></td></tr>

</table>
</form>";


}	
}
