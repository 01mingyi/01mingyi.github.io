<?php


if (@$_POST['act']=='save') {


  if ( (@$_POST['upass2']==@$_POST['upass']) && (strlen(trim(@$_POST['upass2']))>=6) ) {
	
	$uname = trim($_POST['uname']);
	if ($uname != aid() ) {
	  //$content .="<p>非本人帳號</p>";
   	  $content .= redirect("非本人帳號",'index.php?do=admin',2);
   	  exit();
	}	
	
	$info = rsInfo('admin',"uname='$uname'");
	

	
	$data=array();
 // change passport
    $data['upass']=trim($_POST['upass2']);
    rsEdit('admin',$data,"uname='$uname'");  

    //$content .="<p>密碼修改完成</p>";
    $content .= redirect("密碼修改完成",'index.php?do=admin',1);	
		
	
   } else {
   	//$content .="<p>帳號或密碼太短 或其他不符合規定的輸入</p>";
   	$content .= redirect("帳號或密碼太短 或其他不符合規定的輸入",'index.php?do=admin',2);
   }	

	
} else {
	
$uname=aid();
if ($uname) {
//$var = rsInfo('admin',"uname='$uname'");
//echo $uname;
$content.= "<form id='editForm' method='POST' action='index.php?do={$do}' >
<table border=1 width=90% align='center'>
<tr><td>帳號</td><td>$uname<input id='uname' type=hidden name=uname value='$uname'></td></tr>
<tr><td>新密碼</td><td><input id='upass' type=password name='upass' value=''><br>
                     <input id='upass2' type=password name='upass2' value=''><br>
                     請輸入兩次以便確認，密碼至少6個字元
</td></tr>
<tr><td>儲存</td><td><input type=submit value='確認儲存'><input type=hidden name=act value='save'></td></tr>

</table>
</form>
<script src='inc/js/jquery.validate.min.js'></script>
<script>
$(function(){
$('#editForm').validate( 
{

  rules: {
				upass: {
					required: true,
					minlength: 6
				},
				upass2: {
                    required: true,
                    equalTo: '#upass'
                }

				
         },		
  messages: {
			
				upass: {
					required: '<font color=red>必須輸入密碼</font>',
					minlength: '<font color=red>密碼長度必須大於6</font>'
				},
				upass2: {
					required: '<font color=red>必須輸入二次密碼</font>',
					equalTo: '<font color=red>兩次密碼必須相同</font>'
				}
				
            }	
})
});
</script>
";

}	
}

?>