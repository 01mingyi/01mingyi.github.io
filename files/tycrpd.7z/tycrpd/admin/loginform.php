<style>
.my {
    border-radius: 25px;
    border-bottom-right-radius:0;
    border-bottom-left-radius:0;
    background: #2173AD;
    padding: 20px;
    width: 200px;
    height: 50px;
    color:#fff;
    text-align:center;             
}
.my2 {
    
    padding: 0px;
    width: 200px;
    height: 30px;
    text-align:center;
}
.my2> table {
   border : 2px solid #2173AD;
   text-align:center; 
   width:100%;
}

.loginForm {
   margin-top:3%;
}
.my3 {
    border-radius: 25px;
    border-top-right-radius:0;
    border-top-left-radius:0;
    background: #aa6708;
    padding: 20px;
    width: 200px;
    height: 50px;
    color:#fcf8e3;
    text-align:center;             
}

</style>
<?php
  //$caption = '國中科雲端知識庫';
 
  if ($_POST['op']=='login') {

  	$uname = preg_replace('/[^a-zA-Z0-9_]/','',$_POST['uname']); //safe_str($_POST['uname'],ALPHANUM);
  	$info = rsInfo('admin',"uname = '$uname'");
  	if ($info['uname']==$uname && md5($info['upass'])==md5($_POST['upass']) ) {
  	   $_SESSION['log_admin'] = $uname;	
       
   	   echo alert_ok('登入成功','?do='.$do);
       echo "<div class='alert alert-success'>使用說明<a href='/admin/help.pdf' target='_blank'>下載</a></div>";
    } else {
       echo alert_err('登入失敗');  	 	
  	}  	
  } else {
  
  echo "
  <form id='loginForm' class='loginForm' method='post' action='?do=admin'>
  <table  align='center' width=100% style='max-width:360px;'>
  <tr><th class=my>{$caption}</th></tr>
  <tr><td class=my2>
  <table align='center' width=100%   ><tr><td>
  <p height=20px>
  </p>
  <p>
  帳號<INPUT id=uname TYPE=text size=12 NAME='uname' value=''>
  </p>
  <p>
  密碼<INPUT id=upass TYPE=password size=12 NAME='upass' value=''>
  </p>
  <p>
  <input type=hidden name='op' value='login'>
  <INPUT class='btn btn-primary' TYPE=submit VALUE='登入'> 
  </p>
  </td></tr></table>
  </td>
  </tr>
  </table>
  </form>
  <script src='inc/js/jquery.validate.min.js'></script>
  <script src='inc/js/loginform.js'></script>
  
  ";
  }
?>