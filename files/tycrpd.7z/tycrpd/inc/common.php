<?PHP
  
  $UPLOAD_PATH = dirname(__DIR__).'/files';
//  $UPLOAD_URL = "http://game.tyc.edu.tw/files/"; //$_SERVER['SERVER_NAME'].
  $UPLOAD_URL = 'files/';
//////////////// api for admin
function aid() {
  if (isset($_SESSION['log_admin'])) {
    return $_SESSION['log_admin'];	
  } else {
    return "";	
  }	
}
/////////////// api for school
function sid() {
  if (isset($_SESSION['log_school'])) {
    return $_SESSION['log_school'];	
  } else {
    return "";	
  }	
}

/////////////// api for sys option 
function get_sys($tag) {
  return rsInfo('sys',"tag='$tag'",'val');
}


function save_log($msg,$kind,$uname) {
  $data=array();
  $data['msg']=$msg;
  $data['kind']=$kind;
  $data['uname']=$uname;
  $data['logtime']=date('Y-m-d H:i:s');
  rsAdd('log',$data);	
}

//失敗訊息
function alert_err($msg) {
return "
<div class='alert alert-danger' style='margin-top:50px;margin-left:20%;margin-right:20%'>
  <strong>$msg</strong> 
</div>
";

}

//成功訊息
function alert_ok($msg,$nexturl) {
return "
<div class='alert alert-success' style='margin-top:50px;margin-left:20%;margin-right:20%'>
  <strong>$msg</strong> <br><br>
  請點選<a href='{$nexturl}' class='btn btn-success'>下一步</a>繼續
</div>
";

}


function redirect($msg, $url, $time) {
  global $go;
  $go='goto';
  $t=58 + $time*1000;	
  return "
    <script>
 
    $( document ).ready(function() {
       setTimeout(function(){ location.replace('{$url}'); }, $t);
    });
 
    </script>
    <div class='alert alert-success' style='margin-top:50px;margin-left:20%;margin-right:20%;'>
    <div><strong>{$msg}</strong></div>
    <div>已經導向至新網址，如未自動請按下<a href='{$url}'>這裡</a></div>
    </div>
    
    ";
	
}

function escape($str) {
  $str = preg_replace('/\s+/', '', $str);	
  $str = str_replace("'",'',$str);
  $str = str_replace('"','',$str);
  return $str;
}

function arr2opt($arr,$selvalue) {
  $str='';
  foreach ($arr as $key=>$val) {
  	
    $str .= "<option value=$key";
    if ($key==$selvalue) {
       $str .=" selected";	
    }	
    $str .=">$val</option>";	
  }	
  return $str;
}	

function getfilearray($path) {
	global $UPLOAD_PATH;
	//echo $UPLOAD_PATH;
    $files=array();
	if (is_dir($UPLOAD_PATH.'/'.$path)) {
		
	   	$d = dir($UPLOAD_PATH.'/'.$path);
	   	while (false !== ($entry = $d->read())) {
           if (($entry != '.') && ($entry != '..')) $files[]=$entry;
           
        }
        $d->close();
	}	
	return $files;
}	

function randchar() {
  $i=rand(0,25);
  return substr("abcdefghijklmnopqrstuvwxyz",$i,1);
}

function randdigi() {
  $i=rand(0,9);
  return substr("0123456789",$i,1);
}

function randpass() {
  $s =  randchar(). randchar(). randchar();
  $s = strtoupper($s);
  $s .= randdigi().randdigi().randdigi();
  $s .= randchar(). randchar(). randchar();
  return $s;
}

function my_uniqid() {
    return randchar().uniqid();
}

?>