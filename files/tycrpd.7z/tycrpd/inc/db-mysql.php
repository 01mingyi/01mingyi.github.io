<?PHP
//versin 1.5  20181008

$CONN = mysql_connect(DB_HOST, DB_USER, DB_PASS);
if (!$CONN) {
    die('Could not connect: ' . mysql_error());
}

$DB   = mysql_select_db(DB_NAME, $CONN);
mysql_query('set names utf8');
        # create a connection
$LASTSQL='';
//function 

  function rsQuery($sql) {
  	 global $CONN, $LASTSQL; 
  	 $LASTSQL=$sql;
     $rs = mysql_query($sql) or die("ERROR:$sql");
     return $rs;
  }

  function rsSelect($fields="*",$tb,$where,$opt) {
  	 $a = explode('?',$where);
  	 $ma = count($a)-1;
  	 $sql="SELECT $fields FROM $tb WHERE ";
	 
  	 for ($i=0;$i<$ma;$i++) {
  	 	$sql.= $a[$i];
  	 	
  	 	if (isset($opt[$i])) {
  	 		if (is_numeric($opt[$i])) $sql.=$opt[$i];
  	 		else {
  	 		  $val = mysql_real_escape_string($opt[$i]);
  	 		  $sql.="'{$val}'";
  	 		}	
  	 	} else {
  	 	   $sql.="''";	
  	 	}
  	    	
  	 }
 	 
  	 $sql.=$a[$ma];
  	 
  	  $rs=rsQuery($sql);
	  $row=mysql_fetch_assoc($rs);  
	  return $row;   
  }
  
  function rsDict($tb,$where="1",$key,$field="") {
       global $DB;
       if ($field) {
         $_arr = explode(',',$field);
         if ( count($_arr) > 1 ) {
            if (in_array($key,$_arr)) {
               $_field = $field;
               $_type = 1;
            } else {
					  	 $_field = "{$key},{$field}";
               $_type = 3;
            }
         } else {
           	 $_field = "{$key},{$field}";
             $_type = 2;
         } 
       } else {
          	 $_field = "*";
             $_type = 1;
       }
       $sql = "SELECT {$_field} from ". $tb ." where {$where}";
       $rs = rsQuery($sql);
 			 $ret=array();				 
			 if ($_type==1) {
			 		while ( $row = mysql_fetch_assoc($rs) ) {
			       $ret[$row[$key]] = $row;
			 		} 	                
       }
       elseif ($_type==2) {
			 		while ( $row = mysql_fetch_assoc($rs) ) {
			       $ret[$row[$key]] = $row[$field];
			 		} 	                
       }else {
        	while ( $row = mysql_fetch_assoc($rs) ) {
        	    $_key = $row[$key];
        	    unset($row[$key]);
			    $ret[$key] = $row;
			} 	                
       
       }
       return $ret;
     }
  
  function rsArr2Ins($arr) {    
      foreach ($arr as $key=>$value) {
      	 //$value=addslashes($value);
         $arr1[]='`'.$key.'`';
         $arr2[]= "'".mysql_real_escape_string($value)."'";
      }
      return '('.implode(',',$arr1).') VALUES ('.implode(',',$arr2).')';
  }
    
  function rsArr2Set($arr) {      
      foreach ($arr as $key=>$value) {
      	 //$value=addslashes($value);
      	 $value=str_replace("'","\'",$value); //what wrong
         $arr1[]='`'.$key.'`='. "'".mysql_real_escape_string($value)."'";
      }
      return 'SET '.implode(',',$arr1).' ';
  }
    
  function rsEdit($tb, $arr, $where="0"){
       $sql="UPDATE ". $tb .' '. rsArr2Set($arr).' where '.$where;
       //echo $sql;
	   //die($sql);   
       rsQuery($sql);
  }
    
  function rsDel($tb,$where="0"){
       global $xoopsDB;
       $sql="DELETE from ".$tb.' where '.$where;
       rsQuery($sql);
  }
    
  function rsDelF($tb,$where="0"){
       global $xoopsDB;
       $sql="DELETE from ".$tb.' where '.$where;
       rsQuery($sql);
  }
    
  function rsRepl($tb, $arr){
       global $xoopsDB;
       $sql="REPLACE into ". $tb.' '. rsArr2Ins($arr);
       rsQuery($sql);
  }
    
  function rsAdd($tb, $arr) {       
       global $xoopsDB;
       $sql="INSERT into ".$tb.' '. rsArr2Ins($arr);
       rsQuery($sql);
       return mysql_insert_id();
 }

 	function rsInfo($tb,$where="1",$field="") {
      $sql="select * from  ".$tb." where {$where}";
	    //echo $sql.'<br>';
        
      $rs=rsQuery($sql);
	  $row=mysql_fetch_assoc($rs);  
	    if ($field) return $row[$field]; else return $row; 
	}
	
	function rsList($tb,$where="1",$field="") {
      if (!$field) $field='*';  
      $sql="select {$field} from  ".$tb." where {$where}";
      $rs=mysql_query($sql);
	    $data=array();  
	     while  ($row=mysql_fetch_assoc($rs)) {
		     $data[]=$row;
		  } 

	    return $data;
	}

    function ezList($sql) {
      //if (!$field) $field='*';  
      //$sql="select {$field} from  ".$tb." where {$where}";
      $rs=mysql_query($sql);
	    $data=array();  
	     while  ($row=mysql_fetch_assoc($rs)) {
		     $data[]=$row;
		  } 

	    return $data;
	}

    function ezDic($sql,$key,$val) {
      //if (!$field) $field='*';  
      //$sql="select {$field} from  ".$tb." where {$where}";
      $rs=mysql_query($sql);
	    $data=array();  
	     while  ($row=mysql_fetch_assoc($rs)) {
		     $data[$row[$key]]=$row[$val];
		  } 

	    return $data;
	}

	
	function rsCount($tb,$where="1") {
     
      $sql="select count(*) as c from  `".$tb."` where {$where}";
      //echo $sql;
      $rs=mysql_query($sql);
	    $row=mysql_fetch_assoc($rs);
	    //echo $row['c'];
	  return $row['c']; 
	}
	
	function rsMax($tb,$where="1",$field) {
      global $xoopsDB;

      $sql="select MAX( `{$field}` ) as c from  ".$tb." where {$where}";

      $rs=rsQuery($sql);
	  $row=mysql_fetch_array($rs);
	  return $row['c']; 
	}


?>
