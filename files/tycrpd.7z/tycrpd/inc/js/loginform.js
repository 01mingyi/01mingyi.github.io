// JavaScript Document
$.validator.addMethod(
    'alphanum',
    function(value, element) {
        // put your own logic here, this is just a (crappy) example
        return value.match(/^[a-zA-Z0-9]+$/);
    },
    '<font color=red>只能英文字母和數字</font>'
);

$(function(){

$('#loginForm').validate( 
{

  rules: {
                uname: {
					required: true,
					minlength: 3,
					alphanum :true
				},
				upass: {
					required: true,
					minlength: 6
				}
				
         },		
  messages: {

                uname: {
					required: '<font color=red>必須輸入帳號</font>',
					minlength: '<font color=red>帳號長度必須大於3</font>'
				},
				upass: {
					required: '<font color=red>必須輸入密碼</font>',
					minlength: '<font color=red>密碼長度必須大於6</font>'
				}
            }	
})
});