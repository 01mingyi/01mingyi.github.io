<?php

$fileid=$_GET["file"];

if( empty($fileid) ){ die("檔案不存在1"); }

$row = rsInfo('files',"fileid='$fileid'");

if($row['id']=='0' ){ die("檔案不存在2"); } 
if($row['stat']==0 ){ die("檔案不存在3"); } 

$file_name=$row['filename'] ;
$file_name = $file_name . "." .$row['fileext'] ;
$year = substr($fileid,0,2) ; //年度資料夾
$file_path = $UPLOAD_PATH .'/' . $year ."/" . $fileid . "." .$row['fileext'];
header('Content-type:application/force-download'); //告訴瀏覽器 為下載 
header('Content-Transfer-Encoding: Binary'); //編碼方式
header('Content-Disposition:attachment;filename='.$file_name); //檔名
readfile($file_path);
exit ;

