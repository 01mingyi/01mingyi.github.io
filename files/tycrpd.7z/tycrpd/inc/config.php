<?PHP
//===========================================================================
//[0]DATABASE
//===========================================================================

define('DB_HOST','localhost');
define('DB_USER','');
define('DB_PASS','');
define('DB_NAME','tycrpd');   //the name of database

if (function_exists('mysqli_connect')) {
   include __DIR__.'/db.php';
} else {
   include __DIR__.'/db-mysql.php';
}


//===========================================================================
//[1] constant
//===========================================================================

// MENU_KIND
define('MENU_LINK',0); //使用者自訂連結
define('MENU_SYS',1); //系統定義
define('MENU_CATE',2); //來自分類











